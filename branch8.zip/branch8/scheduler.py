from itertools import combinations

class Course:

    def __init__(self, code, section, days, start, end):

        self.code = code

        self.section = section

        self.days = days

        self.start = int(start)

        self.end = int(end)

def parse_file(filename):

    courses = []

    with open(filename, 'r') as f:

        for line in f:

            parts = line.split()

            if len(parts) != 5:

                continue

            courses.append(Course(*parts))

    return courses

def overlap(c1, c2):

    if not (set(c1.days) & set(c2.days)):

        return False

    return not (c1.end <= c2.start or c2.end <= c1.start)

def valid_schedule(schedule):

    for i in range(len(schedule)):

        for j in range(i + 1, len(schedule)):

            if overlap(schedule[i], schedule[j]):

                return False

    return True

def find_schedule(selected_courses):

    n = len(selected_courses)

    for size in range(n, 0, -1):

        for combo in combinations(selected_courses, size):

            if valid_schedule(combo):

                return combo

    return None